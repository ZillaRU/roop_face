
  Guide to deploying deep-learning inference networks and deep vision primitives on Sophon TPU.
  
